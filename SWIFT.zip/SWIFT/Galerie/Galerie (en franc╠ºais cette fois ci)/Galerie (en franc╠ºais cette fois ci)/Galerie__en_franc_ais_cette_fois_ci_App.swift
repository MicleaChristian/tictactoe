//
//  Galerie__en_franc_ais_cette_fois_ci_App.swift
//  Galerie (en français cette fois ci)
//
//  Created by goldorak on 12/09/2023.
//

import SwiftUI

@main
struct Galerie__en_franc_ais_cette_fois_ci_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
