//
//  Carte_de_visiteApp.swift
//  Carte de visite
//
//  Created by goldorak on 12/09/2023.
//

import SwiftUI

@main
struct Carte_de_visiteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
