//
//  GalleryApp.swift
//  Gallery
//
//  Created by goldorak on 12/09/2023.
//

import SwiftUI

@main
struct GalleryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
